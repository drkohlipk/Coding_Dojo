for i in range(1, 1000, 2):
	print i
