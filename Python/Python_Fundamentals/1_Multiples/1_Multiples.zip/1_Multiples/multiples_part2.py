for i in range(5, 1000000, 5):
	print i
