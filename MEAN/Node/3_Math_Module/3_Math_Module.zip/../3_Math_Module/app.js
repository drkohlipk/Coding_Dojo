var mathlib = (require('./mathlib'))();

console.log(mathlib.random(5, 10));
