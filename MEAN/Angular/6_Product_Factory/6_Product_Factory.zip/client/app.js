const app = angular.module('productApp', []);
