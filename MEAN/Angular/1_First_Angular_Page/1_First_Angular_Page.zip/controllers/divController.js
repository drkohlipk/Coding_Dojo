appModule.controller('divController', function($scope) {
    $scope.myName = 'PJ';
    $scope.myFavoriteLanguage = 'JavaScript';
    $scope.myFavoriteJSLibrary = 'Angular';
});
