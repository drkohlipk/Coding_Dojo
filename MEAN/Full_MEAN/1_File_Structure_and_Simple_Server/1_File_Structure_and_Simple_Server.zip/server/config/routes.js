console.log('future routes');

module.exports = function(app) {

};
