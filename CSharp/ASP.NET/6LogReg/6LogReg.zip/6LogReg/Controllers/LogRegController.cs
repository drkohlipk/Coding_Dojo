using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using LogReg.Factory;
using LogReg.Models;

namespace LogReg.Controllers
{
    public class LogRegController : Controller
    {
        private readonly UserFactory userFactory;
        public static List<string> errors = new List<string>();
        public static string whichErr = null;
        public static User currUser = null;
		public LogRegController(UserFactory user)
		{
			userFactory = user;
		}
        [HttpGetAttribute]
        [Route("")]
        public IActionResult Index()
        {
            ViewBag.showReg = false;
            ViewBag.showLog = false;
            ViewBag.errors = errors;
            if (whichErr == "log")
            {
                ViewBag.showLog = true;
            }
            else if (whichErr == "reg")
            {
                ViewBag.showReg = true;
            }
            return View();
        }

        [HttpPostAttribute]
        [Route("register")]
        public IActionResult Register(User NewUser)
        {
            errors.Clear(); //clear out all errors to begin
            whichErr = null;
            currUser = userFactory.FindByEmail(NewUser.email);
            if (ModelState.IsValid) //if the data entered in the inputs meets the min requirements as set forth in models...
            {
                if (currUser != null) 
                {
                    errors.Add("User already exists, please log in.");
                    whichErr = "reg";
                }
                else
                {
                    PasswordHasher<User> Hasher = new PasswordHasher<User>();
                    NewUser.password = Hasher.HashPassword(NewUser, NewUser.password);
                    currUser = userFactory.Add(NewUser); //send the NewUser object (with populated information) to the userFactory to add to the DB
                    whichErr = null;
                    return RedirectToAction("Success"); //return to the User page
                }
            }
            else
            {
                foreach (var error in ModelState.Values) //for every object in the list of ModelState.Values
                {
                    if(error.Errors.Count > 0) //assuming the Error count is greater than 0
                    {
                        string errorMess = (string)error.Errors[0].ErrorMessage; //create a string to store each error message
                        errors.Add(errorMess); //add that message to the errors list
                        whichErr = "reg";
                    }
                }
            }
            return RedirectToAction("Index"); //return the user to Index
        }

        [HttpPostAttribute]
        [Route("login")]
        public IActionResult Login(LogUser NewLogUser)
        {
            errors.Clear(); //clear out all errors to begin
            whichErr = null;
            currUser = userFactory.FindByEmail(NewLogUser.email);
            if (ModelState.IsValid) //if the data entered in the inputs meets the min requirements as set forth in models...
            {
                var Hasher = new PasswordHasher<User>();
                if (currUser == null) 
                {
                    errors.Add("Username or password incorrect.");
                    whichErr = "log";
                }
                else if (Hasher.VerifyHashedPassword(currUser, currUser.password, NewLogUser.password) == 0)
                {
                    errors.Add("Username or password incorrect.");
                    whichErr = "log";
                }
                else
                {
                    whichErr = null;
                    ViewBag.name = currUser.first_name;
                    return RedirectToAction("Success"); //return to the User page
                }
            }
            else
            {
                foreach (var error in ModelState.Values) //for every object in the list of ModelState.Values
                {
                    if(error.Errors.Count > 0) //assuming the Error count is greater than 0
                    {
                        string errorMess = (string)error.Errors[0].ErrorMessage; //create a string to store each error message
                        errors.Add(errorMess); //add that message to the errors list
                        whichErr = "log";
                    }
                }
            }
            return RedirectToAction("Index"); //return the user to Index
        }

        [HttpGetAttribute]
        [Route("success")]
        public IActionResult Success()
        {
            if (currUser == null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.name = currUser.first_name;
                return View("Success");
            }
        }

        [HttpGetAttribute]
        [Route("logout")]
        public IActionResult Logout()
        {
            currUser = null;
            return RedirectToAction("Index");
        }
    }
}
