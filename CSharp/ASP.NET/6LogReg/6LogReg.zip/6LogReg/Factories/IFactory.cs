using LogReg.Models;
using System.Collections.Generic;

namespace LogReg.Factory
{
	public interface IFactory<T> where T : BaseEntity
	{
	}
}