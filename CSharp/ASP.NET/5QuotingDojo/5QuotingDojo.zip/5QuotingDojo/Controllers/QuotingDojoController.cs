using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using QuotingDojo.Models;
using QuotingDojo.Factory;

namespace QuotingDojo.Controllers
{
    public class QuotingDojoController : Controller
    {
        private readonly QuoteFactory quoteFactory;
        public static List<string> errors = new List<string>();
        public QuotingDojoController()
        {
            quoteFactory = new QuoteFactory();
        }

        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            if (errors.Count > 0)
            {
                ViewBag.Errors = errors;
            }
            return View();
        }

        [HttpGet]
        [Route("Quotes")]
        public IActionResult Quotes()
        {
            errors.Clear();
            List<Quote> allQuotes = (List<Quote>)quoteFactory.FindAll();
            if (allQuotes.Count > 0)
            {
                ViewBag.quoteShow = true;
                ViewBag.quotes = allQuotes;
            }
            else
            {
                ViewBag.quoteShow = false;
            }
            return View("Quotes");
        }
        
        [HttpPost]
        [Route("addQuote")]
        public IActionResult addQuote(Quote NewQuote)
        {
            errors.Clear();
            if (ModelState.IsValid)
            {
                quoteFactory.Add(NewQuote);
                return RedirectToAction("Quotes");
            }
            else 
            {
                foreach (var error in ModelState.Values)
                {
                    if(error.Errors.Count > 0)
                    {
                        string errorMess = (string)error.Errors[0].ErrorMessage;
                        errors.Add(errorMess);
                    }
                }
                return RedirectToAction("Index");
            }
        }

        [HttpGet]
        [RouteAttribute("like/{id}")]
        public IActionResult like(int id)
        {
            quoteFactory.LikeByID(id);
            return RedirectToAction("Quotes");
        }

        [HttpGet]
        [RouteAttribute("update/{id}")]
        public IActionResult update(int id)
        {
            if (errors.Count > 0)
            {
                ViewBag.Errors = errors;
            }
            Quote upQuote = (Quote)quoteFactory.FindByID(id);
            ViewBag.name = upQuote.Name;
            ViewBag.quote = upQuote.QuoteText;
            ViewBag.id = upQuote.Id;
            return View("Update");
        }

        [HttpPost]
        [Route("updateQuote")]
        public IActionResult updateQuote(Quote NewQuote)
        {
            errors.Clear();
            if (ModelState.IsValid)
            {
                quoteFactory.Update(NewQuote);
                return RedirectToAction("Quotes");
            }
            else 
            {
                foreach (var error in ModelState.Values)
                {
                    if(error.Errors.Count > 0)
                    {
                        string errorMess = (string)error.Errors[0].ErrorMessage;
                        errors.Add(errorMess);
                    }
                }
                return RedirectToAction("Update", new {id = NewQuote.Id});
            }
        }

        [HttpGet]
        [RouteAttribute("delete/{id}")]
        public IActionResult delete(int id)
        {
            quoteFactory.DeleteByID(id);
            return RedirectToAction("Quotes");
        }
    }
}
