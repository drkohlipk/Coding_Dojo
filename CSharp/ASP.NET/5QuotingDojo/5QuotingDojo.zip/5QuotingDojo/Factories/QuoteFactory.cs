using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Data;
using MySql.Data.MySqlClient;
using QuotingDojo.Models;

namespace QuotingDojo.Factory
{
	public class QuoteFactory : IFactory<Quote>
	{
		private string connectionString;
		public QuoteFactory()
		{
			connectionString = "server=localhost;userid=root;password=root;port=8889;database=quoting_Dojo;SslMode=None";
		}
		internal IDbConnection Connection
		{
			get {
				return new MySqlConnection(connectionString);
			}
		}
		public void Add(Quote item)
        {
            using (IDbConnection dbConnection = Connection) {
                string query = "INSERT INTO quotes (name, quoteText, likes, created_at, updated_at) VALUES (@Name, @QuoteText, @Likes, NOW(), NOW())";
                dbConnection.Open();
                dbConnection.Execute(query, item);
            }
        }
        public IEnumerable<Quote> FindAll()
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                return dbConnection.Query<Quote>("SELECT id, name, quotetext, likes, DATE_FORMAT(created_at, '%l:%i%p %M %e %Y') AS created_at FROM quotes ORDER BY likes DESC");
            }
        }
        public Quote FindByID(int id)
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                return dbConnection.Query<Quote>("SELECT * FROM quotes WHERE id = @Id", new { Id = id }).FirstOrDefault();
            }
        }
		public void LikeByID(int id)
		{
			using (IDbConnection dbConnection = Connection)
			{
				string query = $"UPDATE quotes SET likes = likes + 1 WHERE id = {id}";
				dbConnection.Open();
				dbConnection.Execute(query);
			}
		}
		public void Update(Quote item)
		{
			using (IDbConnection dbConnection = Connection)
			{
				string query = "UPDATE quotes SET name = @Name, quoteText = @QuoteText WHERE id = @Id";
                dbConnection.Open();
                dbConnection.Execute(query, item);
			}
		}
		public void DeleteByID(int id)
		{
			using (IDbConnection dbConnection = Connection)
			{
				string query = $"DELETE FROM quotes WHERE id = {id}";
				dbConnection.Open();
				dbConnection.Execute(query);
			}
		}
	}
}