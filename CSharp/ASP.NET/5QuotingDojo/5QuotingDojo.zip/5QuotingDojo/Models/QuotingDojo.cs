
using System.ComponentModel.DataAnnotations;

namespace QuotingDojo.Models
{
	public abstract class BaseEntity {}
	public class Quote : BaseEntity
	{
		[Required]
		[MinLength(2)]
		public string Name { get; set; }
		[Required]
		[MinLength(1)]
		public string QuoteText { get; set; }
		public int Likes { get; set; }
		public string Created_At{ get; set; }
		public int Id { get; set; }
	}
}