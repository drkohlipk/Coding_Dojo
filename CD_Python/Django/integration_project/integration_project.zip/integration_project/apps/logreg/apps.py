from django.apps import AppConfig


class LogregConfig(AppConfig):
    name = 'logreg'
