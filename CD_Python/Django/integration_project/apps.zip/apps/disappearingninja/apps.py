from django.apps import AppConfig


class DisappearingninjaConfig(AppConfig):
    name = 'disappearingninja'
