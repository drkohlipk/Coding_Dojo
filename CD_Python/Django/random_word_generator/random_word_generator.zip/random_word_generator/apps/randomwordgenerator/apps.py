from django.apps import AppConfig


class RandomwordgeneratorConfig(AppConfig):
    name = 'randomwordgenerator'
