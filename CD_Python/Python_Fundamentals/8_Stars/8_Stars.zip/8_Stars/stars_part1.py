x = [4, 6, 1, 3, 5, 7, 25]

def print_Stars(arr):
	for i in arr:
		print i * "*"

print_Stars(x)
